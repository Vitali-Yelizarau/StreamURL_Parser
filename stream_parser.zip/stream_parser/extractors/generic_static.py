import re
import sys
from typing import List, Set
from urllib.parse import urlparse, urljoin

from bs4 import BeautifulSoup

from stream_parser.http_client import HttpClient
from stream_parser.models import ParserResult, StreamCandidate
from stream_parser.stream_validator import StreamValidator

# ---- stream_parser hotfix: safe urlparse for malformed JS/template URLs ----
# Some JS bundles contain URL-looking template fragments with broken square
# brackets. urllib.parse.urlparse() can raise ValueError("Invalid IPv6 URL") on
# them. Static extraction must skip such garbage instead of killing the whole
# parser before the browser fallback runs.
_stream_parser_raw_urlparse = urlparse


class _StreamParserSafeParsedUrl:
    def __init__(self):
        self.scheme = ""
        self.netloc = ""
        self.path = ""
        self.params = ""
        self.query = ""
        self.fragment = ""
        self.hostname = None
        self.port = None


def _stream_parser_safe_urlparse(value):
    try:
        return _stream_parser_raw_urlparse(value)
    except Exception:
        return _StreamParserSafeParsedUrl()


urlparse = _stream_parser_safe_urlparse
# ---- end hotfix ----


class GenericStaticExtractor:
    MAX_SCRIPT_FILES_TO_DOWNLOAD = 40
    MAX_TEXT_FILES_TO_DOWNLOAD = 25
    MAX_PLAYLIST_FILES_TO_DOWNLOAD = 25
    MAX_CANDIDATES_TO_VALIDATE = 80

    def __init__(self, timeout: int = 15, debug: bool = False):
        self.timeout = timeout
        self.debug = debug
        self.http = HttpClient(timeout=timeout, debug=debug)
        self.validator = StreamValidator(timeout=timeout, debug=debug)

    def log(self, message: str):
        if self.debug:
            print(message, file=sys.stderr)

    def can_handle(self, url: str) -> bool:
        if not url:
            return False

        parsed = urlparse(url)

        return parsed.scheme.lower() in ("http", "https") and bool(parsed.netloc)

    def discover(self, url: str) -> ParserResult:
        diagnostics: List[str] = []
        candidates: List[StreamCandidate] = []

        downloaded_scripts: Set[str] = set()
        downloaded_text_files: Set[str] = set()
        downloaded_playlists: Set[str] = set()

        diagnostics.append("Generic static extractor selected.")
        diagnostics.append("No platform-specific URL generation is used.")

        html = self.http.download_text_safe(url)

        if not html:
            return ParserResult(
                success=False,
                inputUrl=url,
                effectiveUrl=url,
                title="",
                candidates=[],
                diagnostics=diagnostics,
                error="Input page was not downloaded or was empty."
            )

        diagnostics.append(f"Downloaded input page. Length: {len(html)}")

        candidates.extend(
            self._extract_stream_candidates_from_text(
                text=html,
                base_url=url,
                origin_url=url,
                origin_type="input_html"
            )
        )

        discovered_urls = self._extract_all_urls_from_text(html, url)
        diagnostics.append(f"URLs found in input page: {len(discovered_urls)}")

        candidates.extend(
            self._build_candidates_from_urls(
                urls=discovered_urls,
                origin_url=url,
                origin_type="input_html_url"
            )
        )

        script_urls = self._filter_script_urls(discovered_urls)
        text_urls = self._filter_text_like_urls(discovered_urls)
        playlist_urls = self._filter_playlist_urls(discovered_urls)

        diagnostics.append(f"Script URLs queued: {len(script_urls)}")
        diagnostics.append(f"Text/API URLs queued: {len(text_urls)}")
        diagnostics.append(f"Playlist URLs queued: {len(playlist_urls)}")

        self._scan_script_files(
            script_urls=script_urls,
            candidates=candidates,
            playlist_urls=playlist_urls,
            text_urls=text_urls,
            downloaded_scripts=downloaded_scripts,
            diagnostics=diagnostics
        )

        self._scan_text_files(
            text_urls=text_urls,
            candidates=candidates,
            playlist_urls=playlist_urls,
            downloaded_text_files=downloaded_text_files,
            diagnostics=diagnostics
        )

        self._scan_playlist_files(
            playlist_urls=playlist_urls,
            candidates=candidates,
            downloaded_playlists=downloaded_playlists,
            diagnostics=diagnostics
        )

        candidates = self._deduplicate_candidates(candidates)

        diagnostics.append(f"Candidate count before validation: {len(candidates)}")

        candidates = candidates[:self.MAX_CANDIDATES_TO_VALIDATE]
        candidates = self._validate_candidates(candidates)

        diagnostics.append(f"Playable candidate count after validation: {len(candidates)}")

        return ParserResult(
            success=len(candidates) > 0,
            inputUrl=url,
            effectiveUrl=url,
            title="",
            candidates=candidates,
            diagnostics=diagnostics,
            error=None if candidates else "No playable stream candidates found by generic static extractor."
        )

    def _scan_script_files(
        self,
        script_urls: List[str],
        candidates: List[StreamCandidate],
        playlist_urls: List[str],
        text_urls: List[str],
        downloaded_scripts: Set[str],
        diagnostics: List[str]
    ):
        for script_url in self._deduplicate_strings(script_urls)[:self.MAX_SCRIPT_FILES_TO_DOWNLOAD]:
            key = script_url.lower()

            if key in downloaded_scripts:
                continue

            downloaded_scripts.add(key)

            script_text = self.http.download_text_safe(script_url)

            if not script_text:
                continue

            diagnostics.append(f"Downloaded script. Url: {script_url}, Length: {len(script_text)}")

            candidates.extend(
                self._extract_stream_candidates_from_text(
                    text=script_text,
                    base_url=script_url,
                    origin_url=script_url,
                    origin_type="javascript"
                )
            )

            urls_from_script = self._extract_all_urls_from_text(script_text, script_url)

            candidates.extend(
                self._build_candidates_from_urls(
                    urls=urls_from_script,
                    origin_url=script_url,
                    origin_type="javascript_url"
                )
            )

            playlist_urls.extend(self._filter_playlist_urls(urls_from_script))
            text_urls.extend(self._filter_text_like_urls(urls_from_script))

    def _scan_text_files(
        self,
        text_urls: List[str],
        candidates: List[StreamCandidate],
        playlist_urls: List[str],
        downloaded_text_files: Set[str],
        diagnostics: List[str]
    ):
        for text_url in self._deduplicate_strings(text_urls)[:self.MAX_TEXT_FILES_TO_DOWNLOAD]:
            key = text_url.lower()

            if key in downloaded_text_files:
                continue

            downloaded_text_files.add(key)

            text = self.http.download_text_safe(text_url)

            if not text:
                continue

            diagnostics.append(f"Downloaded text/API file. Url: {text_url}, Length: {len(text)}")

            candidates.extend(
                self._extract_stream_candidates_from_text(
                    text=text,
                    base_url=text_url,
                    origin_url=text_url,
                    origin_type="text_or_api"
                )
            )

            urls_from_text = self._extract_all_urls_from_text(text, text_url)

            candidates.extend(
                self._build_candidates_from_urls(
                    urls=urls_from_text,
                    origin_url=text_url,
                    origin_type="text_or_api_url"
                )
            )

            playlist_urls.extend(self._filter_playlist_urls(urls_from_text))

    def _scan_playlist_files(
        self,
        playlist_urls: List[str],
        candidates: List[StreamCandidate],
        downloaded_playlists: Set[str],
        diagnostics: List[str]
    ):
        for playlist_url in self._deduplicate_strings(playlist_urls)[:self.MAX_PLAYLIST_FILES_TO_DOWNLOAD]:
            key = playlist_url.lower()

            if key in downloaded_playlists:
                continue

            downloaded_playlists.add(key)

            playlist_text = self.http.download_text_safe(playlist_url)

            if not playlist_text:
                continue

            diagnostics.append(f"Downloaded playlist. Url: {playlist_url}, Length: {len(playlist_text)}")

            candidates.extend(
                self._extract_candidates_from_playlist(
                    playlist_text=playlist_text,
                    playlist_url=playlist_url
                )
            )

            candidates.extend(
                self._extract_stream_candidates_from_text(
                    text=playlist_text,
                    base_url=playlist_url,
                    origin_url=playlist_url,
                    origin_type="playlist_text"
                )
            )

    def _extract_all_urls_from_text(self, text: str, base_url: str) -> List[str]:
        result: List[str] = []

        if not text:
            return result

        normalized = self._normalize_text(text)

        result.extend(self._extract_urls_with_beautifulsoup(normalized, base_url))
        result.extend(self._extract_absolute_urls_with_regex(normalized))
        result.extend(self._extract_protocol_relative_urls_with_regex(normalized))
        result.extend(self._extract_relevant_relative_urls_with_regex(normalized, base_url))

        return self._deduplicate_strings([
            self._clean_url(x)
            for x in result
            if x
        ])

    def _extract_urls_with_beautifulsoup(self, text: str, base_url: str) -> List[str]:
        result: List[str] = []

        try:
            soup = BeautifulSoup(text, "lxml")
        except Exception:
            return result

        attributes = [
            "src",
            "href",
            "data-src",
            "data-url",
            "data-href",
            "data-stream",
            "data-audio",
            "data-file",
            "data-playlist",
            "poster"
        ]

        for tag in soup.find_all(True):
            for attribute in attributes:
                value = tag.get(attribute)

                if not value:
                    continue

                value = str(value).strip()

                if not value:
                    continue

                if value.startswith("javascript:"):
                    continue

                if value.startswith("#"):
                    continue

                result.append(urljoin(base_url, value))

        return result

    def _extract_absolute_urls_with_regex(self, text: str) -> List[str]:
        result: List[str] = []

        pattern = r"https?:\/\/[^\"'<>\s\\)]+"

        for match in re.finditer(pattern, text, flags=re.IGNORECASE):
            result.append(match.group(0))

        return result

    def _extract_protocol_relative_urls_with_regex(self, text: str) -> List[str]:
        result: List[str] = []

        pattern = r"(?<!:)\/\/[^\"'<>\s\\)]+"

        for match in re.finditer(pattern, text, flags=re.IGNORECASE):
            result.append("https:" + match.group(0))

        return result

    def _extract_relevant_relative_urls_with_regex(self, text: str, base_url: str) -> List[str]:
        result: List[str] = []

        pattern = (
            r"[\"']"
            r"(?P<url>\/[^\"'<>\\\s]*"
            r"(?:stream|audio|radio|live|listen|playlist|m3u8|m3u|pls|aac|mp3)"
            r"[^\"'<>\\\s]*)"
            r"[\"']"
        )

        for match in re.finditer(pattern, text, flags=re.IGNORECASE):
            relative_url = match.group("url")
            result.append(urljoin(base_url, relative_url))

        return result

    def _extract_stream_candidates_from_text(
        self,
        text: str,
        base_url: str,
        origin_url: str,
        origin_type: str
    ) -> List[StreamCandidate]:
        urls = self._extract_all_urls_from_text(text, base_url)

        return self._build_candidates_from_urls(
            urls=urls,
            origin_url=origin_url,
            origin_type=origin_type
        )

    def _build_candidates_from_urls(
        self,
        urls: List[str],
        origin_url: str,
        origin_type: str
    ) -> List[StreamCandidate]:
        result: List[StreamCandidate] = []

        for found_url in urls:
            cleaned = self._clean_url(found_url)

            if not cleaned:
                continue

            if not self._is_stream_like_url(cleaned):
                continue

            result.append(StreamCandidate(
                url=cleaned,
                title="",
                source="generic_static",
                confidence=self._get_candidate_confidence(cleaned),
                reason=f"Found stream-like URL in {origin_type}.",
                originUrl=origin_url,
                originType=origin_type
            ))

        return result

    def _extract_candidates_from_playlist(
        self,
        playlist_text: str,
        playlist_url: str
    ) -> List[StreamCandidate]:
        result: List[StreamCandidate] = []

        if not playlist_text:
            return result

        lines = playlist_text.replace("\r\n", "\n").replace("\r", "\n").split("\n")

        for raw_line in lines:
            line = raw_line.strip()

            if not line:
                continue

            if line.startswith("#"):
                continue

            if "=" in line:
                key, value = line.split("=", 1)

                if key.strip().lower().startswith("file"):
                    line = value.strip()

            if not line:
                continue

            absolute_url = urljoin(playlist_url, line)
            cleaned = self._clean_url(absolute_url)

            if not cleaned:
                continue

            if not self._is_stream_like_url(cleaned):
                continue

            result.append(StreamCandidate(
                url=cleaned,
                title="",
                source="generic_static",
                confidence=self._get_candidate_confidence(cleaned),
                reason="Found stream-like URL inside playlist.",
                originUrl=playlist_url,
                originType="playlist"
            ))

        return result

    def _filter_script_urls(self, urls: List[str]) -> List[str]:
        result: List[str] = []

        for url in urls:
            lower = url.lower()
            parsed = urlparse(url)
            path = parsed.path.lower()

            if self._is_probably_static_non_text_asset(url):
                continue

            if path.endswith(".js") or ".js?" in lower:
                result.append(url)

        return self._deduplicate_strings(result)

    def _filter_playlist_urls(self, urls: List[str]) -> List[str]:
        return self._deduplicate_strings([
            url for url in urls
            if self._is_playlist_url(url)
        ])

    def _filter_text_like_urls(self, urls: List[str]) -> List[str]:
        result: List[str] = []

        for url in urls:
            lower = url.lower()
            parsed = urlparse(url)
            path = parsed.path.lower()

            if self._is_stream_like_url(url):
                continue

            if self._is_probably_static_non_text_asset(url):
                continue

            if path.endswith(".json") or ".json?" in lower:
                result.append(url)
                continue

            if "/api/" in lower:
                result.append(url)
                continue

            if "config" in lower:
                result.append(url)
                continue

            if "metadata" in lower:
                result.append(url)
                continue

            if "playlist" in lower:
                result.append(url)
                continue

            if "player" in lower and not path.endswith(".html"):
                result.append(url)
                continue

        return self._deduplicate_strings(result)

    def _is_stream_like_url(self, url: str) -> bool:
        if not url:
            return False

        cleaned = self._clean_url(url)
        lower = cleaned.lower()

        if self._is_probably_static_non_text_asset(lower):
            return False

        parsed = urlparse(cleaned)
        host = parsed.netloc.lower()
        path = parsed.path.lower()

        if self._is_playlist_url(cleaned):
            return True

        audio_extensions = [
            ".mp3",
            ".aac",
            ".ogg",
            ".opus",
            ".flac",
            ".wav"
        ]

        if any(path.endswith(ext) for ext in audio_extensions):
            return True

        stream_path_tokens = [
            "/stream",
            "/live",
            "/listen",
            "/icecast",
            "/shoutcast",
            "/radio.mp3",
            "/audio",
            "/aac",
            "/mp3"
        ]

        if any(token in path for token in stream_path_tokens):
            return True

        stream_host_tokens = [
            "stream",
            "streams",
            "icecast",
            "shoutcast",
            "listen",
            "live",
            "radio",
            "webradio"
        ]

        if any(token in host for token in stream_host_tokens) and not path.endswith(".html"):
            return True

        known_stream_hosts = [
            "datacenter.by",
            "myradiostream.com",
            "rcast.net",
            "hostingradio.ru",
            "amperwave.net",
            "securenetsystems.net"
        ]

        if any(token in host for token in known_stream_hosts):
            return True

        return False

    def _is_playlist_url(self, url: str) -> bool:
        if not url:
            return False

        lower = url.lower()
        parsed = urlparse(url)
        path = parsed.path.lower()

        return (
            path.endswith(".m3u8")
            or path.endswith(".m3u")
            or path.endswith(".pls")
            or path.endswith(".xspf")
            or ".m3u8?" in lower
            or ".m3u?" in lower
            or ".pls?" in lower
            or ".xspf?" in lower
        )

    def _is_probably_static_non_text_asset(self, url: str) -> bool:
        lower = url.lower()
        parsed = urlparse(lower)
        path = parsed.path.lower()

        blocked_extensions = [
            ".css",
            ".png",
            ".jpg",
            ".jpeg",
            ".webp",
            ".gif",
            ".svg",
            ".ico",
            ".woff",
            ".woff2",
            ".ttf",
            ".eot",
            ".mp4",
            ".webm",
            ".avi",
            ".mov",
            ".pdf",
            ".zip",
            ".rar",
            ".7z"
        ]

        return any(path.endswith(ext) for ext in blocked_extensions)

    def _get_candidate_confidence(self, url: str) -> int:
        lower = url.lower()

        if self._is_playlist_url(url):
            return 90

        if "datacenter.by" in lower:
            return 90

        if "/stream" in lower:
            return 85

        if "icecast" in lower or "shoutcast" in lower:
            return 85

        if "audio" in lower:
            return 80

        if "listen" in lower or "live" in lower:
            return 75

        return 60

    def _validate_candidates(self, candidates: List[StreamCandidate]) -> List[StreamCandidate]:
        validated: List[StreamCandidate] = []

        for candidate in candidates:
            validation = self.validator.validate(candidate.url)

            candidate.isPlayable = validation.is_playable
            candidate.httpStatusCode = validation.status_code
            candidate.contentType = validation.content_type
            candidate.finalUrl = validation.final_url

            if validation.is_playable:
                candidate.confidence = max(candidate.confidence, 95)
                candidate.reason = candidate.reason + " Validated as playable audio stream."
                validated.append(candidate)
            else:
                candidate.reason = candidate.reason + f" Validation failed: {validation.reason}"

        validated.sort(key=lambda x: x.confidence, reverse=True)

        return validated

    def _normalize_text(self, text: str) -> str:
        if not text:
            return ""

        return (
            text
            .replace("\\/", "/")
            .replace("\\u002F", "/")
            .replace("\\u002f", "/")
            .replace("&amp;", "&")
        )

    def _clean_url(self, url: str) -> str:
        if not url:
            return ""

        cleaned = (
            url.strip()
            .strip("\"'")
            .rstrip(".,;)]}")
        )

        return cleaned

    def _deduplicate_candidates(self, candidates: List[StreamCandidate]) -> List[StreamCandidate]:
        result: List[StreamCandidate] = []
        seen = set()

        for candidate in candidates:
            if not candidate.url:
                continue

            key = candidate.url.lower()

            if key in seen:
                continue

            seen.add(key)
            result.append(candidate)

        result.sort(key=lambda x: x.confidence, reverse=True)

        return result

    def _deduplicate_strings(self, values: List[str]) -> List[str]:
        result: List[str] = []
        seen = set()

        for value in values:
            if not value:
                continue

            cleaned = self._clean_url(value)

            if not cleaned:
                continue

            key = cleaned.lower()

            if key in seen:
                continue

            seen.add(key)
            result.append(cleaned)

        return result

# ---- stream_parser hotfix: garbage/static URL guard ----
def _stream_parser_is_js_template_or_static_asset_url(value):
    if not value:
        return True

    text = str(value).strip()
    lower = text.lower()

    if not lower.startswith(("http://", "https://")):
        return True

    bad_tokens = [
        "'+",
        "+'",
        "\"+",
        "+\"",
        "`+",
        "+`",
        "+opts.",
        "+data.",
        "+href",
        "+src",
        "+stream",
        "${",
        "}",
        "{",
        "%22+",
        "%27+",
        "quote/",
        "undefined",
        "null/"
    ]

    if any(token in lower for token in bad_tokens):
        return True

    if any(ch in text for ch in ["\"", "'", "`", "<", ">", "\\"]):
        return True

    try:
        from urllib.parse import urlparse
        parsed = urlparse(lower)
    except Exception:
        return True

    host = parsed.netloc.lower()
    path = parsed.path.lower()

    static_extensions = (
        ".js", ".css", ".png", ".jpg", ".jpeg", ".webp", ".gif",
        ".svg", ".ico", ".woff", ".woff2", ".ttf", ".eot", ".map",
        ".pdf", ".zip", ".rar", ".7z"
    )

    if path.endswith(static_extensions):
        return True

    if "cdn.onlineradiobox.com" in host and path.startswith("/js/"):
        return True

    if "onlineradiobox.com" in host and (
        path.startswith("/track/")
        or path.startswith("/ping/")
        or path.startswith("/js/")
    ):
        return True

    non_stream_tokens = [
        "/music/",
        "/artist/",
        "/artists/",
        "/song/",
        "/songs/",
        "/news/",
        "/article/",
        "/blog/",
        "/privacy",
        "/terms"
    ]

    if any(token in path for token in non_stream_tokens):
        return True

    return False
# ---- end garbage/static URL guard ----


# ---- stream_parser hotfix: protect GenericStaticExtractor from JS template URLs ----
try:
    _stream_parser_original_is_stream_like_url = GenericStaticExtractor._is_stream_like_url

    def _stream_parser_safe_is_stream_like_url(self, url):
        try:
            if _stream_parser_is_js_template_or_static_asset_url(url):
                return False

            return _stream_parser_original_is_stream_like_url(self, url)
        except Exception:
            return False

    GenericStaticExtractor._is_stream_like_url = _stream_parser_safe_is_stream_like_url
except Exception:
    pass
# ---- end GenericStaticExtractor hotfix ----

# ---- stream_parser hotfix: generic static obvious non-stream filter ----
try:
    from urllib.parse import urlparse as _sp_urlparse_static_filter

    _sp_original_static_is_stream_like_url_safe_filter = GenericStaticExtractor._is_stream_like_url

    def _sp_static_obvious_non_stream_url_safe_filter(url):
        if not url:
            return True

        text = str(url).strip()
        lower = text.lower()

        if not lower.startswith(('http://', 'https://')):
            return True

        bad_fragments = [
            "'+",
            "+'",
            '\"+',
            '+\"',
            '`+',
            '+`',
            '${',
            '%22+',
            '%27+',
            '+opts.',
            '+data.',
            '+href',
            '+src',
            '+stream',
            'undefined',
            'null/'
        ]

        if any(fragment in lower for fragment in bad_fragments):
            return True

        if any(ch in text for ch in ['\"', "'", '`', '<', '>', '\\']):
            return True

        try:
            parsed = _sp_urlparse_static_filter(lower)
        except Exception:
            return True

        host = parsed.netloc.lower()
        path = parsed.path.lower()

        blocked_hosts = [
            'googlesyndication.com',
            'doubleclick.net',
            'googletagmanager.com',
            'google-analytics.com',
            'googleadservices.com',
            'amazon-adsystem.com',
            'ahrefs.com',
            'onesignal.com',
            'mailchimp.com',
            'chimpstatic.com',
            'fastly.mmt.delivery',
            'mmt.delivery',
            'vimeo.com'
        ]

        if any(blocked in host for blocked in blocked_hosts):
            return True

        blocked_extensions = (
            '.js', '.css', '.png', '.jpg', '.jpeg', '.webp', '.gif',
            '.svg', '.ico', '.woff', '.woff2', '.ttf', '.eot', '.map',
            '.pdf', '.zip', '.rar', '.7z', '.xml', '.rss', '.atom'
        )

        if path.endswith(blocked_extensions):
            return True

        blocked_path_tokens = [
            '/feed/',
            '/comments/feed/',
            '/web-stories/feed/',
            '/wp-json',
            '/xmlrpc',
            '/sitemap',
            '/track/',
            '/ping/',
            '/privacy',
            '/terms',
            '/tag/',
            '/category/',
            '/author/',
            '/search/'
        ]

        if path.endswith('/feed') or any(token in path for token in blocked_path_tokens):
            return True

        return False

    def _sp_static_is_stream_like_url_safe_filter(self, url):
        try:
            if _sp_static_obvious_non_stream_url_safe_filter(url):
                return False

            return _sp_original_static_is_stream_like_url_safe_filter(self, url)
        except Exception:
            return False

    GenericStaticExtractor._is_stream_like_url = _sp_static_is_stream_like_url_safe_filter

except Exception:
    pass
# ---- end generic static obvious non-stream filter ----
