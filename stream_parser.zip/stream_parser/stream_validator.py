import sys
from dataclasses import dataclass
from urllib.parse import urlparse

import requests


@dataclass
class StreamValidationResult:
    is_playable: bool
    status_code: int = 0
    content_type: str = ""
    final_url: str = ""
    reason: str = ""


class StreamValidator:
    def __init__(self, timeout: int = 10, debug: bool = False):
        self.timeout = timeout
        self.debug = debug

        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/125.0 Safari/537.36"
            ),
            "Accept": "*/*",
            "Icy-MetaData": "1",
        })

    def log(self, message: str):
        if self.debug:
            print(message, file=sys.stderr)

    def validate(self, url: str) -> StreamValidationResult:
        if not url:
            return StreamValidationResult(
                is_playable=False,
                reason="Empty URL."
            )

        try:
            self.log(f"[VALIDATE] Checking stream candidate: {url}")

            response = self.session.get(
                url,
                timeout=self.timeout,
                allow_redirects=True,
                stream=True
            )

            try:
                status_code = response.status_code
                content_type = response.headers.get("Content-Type", "")
                final_url = response.url

                is_audio = self._looks_like_audio_response(
                    status_code=status_code,
                    content_type=content_type,
                    final_url=final_url,
                    headers=response.headers
                )

                self.log(
                    f"[VALIDATE] Status={status_code}, "
                    f"ContentType={content_type}, "
                    f"FinalUrl={final_url}, "
                    f"Playable={is_audio}"
                )

                return StreamValidationResult(
                    is_playable=is_audio,
                    status_code=status_code,
                    content_type=content_type,
                    final_url=final_url,
                    reason="Looks like audio stream." if is_audio else "Response does not look like audio stream."
                )

            finally:
                response.close()

        except Exception as ex:
            self.log(f"[VALIDATE] Failed: {url} | {type(ex).__name__}: {ex}")

            return StreamValidationResult(
                is_playable=False,
                reason=str(ex)
            )

    def _looks_like_audio_response(
        self,
        status_code: int,
        content_type: str,
        final_url: str,
        headers: dict
    ) -> bool:
        if status_code < 200 or status_code >= 400:
            return False

        lower_content_type = (content_type or "").lower()
        lower_url = (final_url or "").lower()

        has_icy_headers = any(
            key.lower().startswith("icy-")
            for key in headers.keys()
        )

        parsed = urlparse(lower_url)
        path = parsed.path.lower()

        if lower_content_type.startswith("audio/"):
            return True

        if "mpegurl" in lower_content_type:
            return True

        if "application/ogg" in lower_content_type:
            return True

        if "application/vnd.apple.mpegurl" in lower_content_type:
            return True

        if "application/x-mpegurl" in lower_content_type:
            return True

        if has_icy_headers:
            return True

        if path.endswith(".m3u8"):
            return True

        if path.endswith(".m3u"):
            return True

        if path.endswith(".pls"):
            return True

        if path.endswith(".mp3"):
            return True

        if path.endswith(".aac"):
            return True

        if path.endswith(".ogg"):
            return True

        if path.endswith(".opus"):
            return True

        return False